/*
Homework 2
HW02_Group07
Kevin Heu, Samuel Petty
*/


package com.example.hw02_group07;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements QuestionAsync.IData {


    public static final String qKey = "Questions";
    private ArrayList<Questions> questions = new ArrayList<>();
    ProgressDialog pd;
    private ImageView trivImage;
    private TextView trivLoad;
    private Button trivStart;
    private Button eButton;
    private Button rButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupViews();
        setupListeners();
        attemptConnection();
    }

    private void attemptConnection() {
        if (isConnectedOnline()){
            rButton.setVisibility(View.INVISIBLE);
            String triviaURL = "http://dev.theappsdr.com/apis/trivia_json/index.php";
            new QuestionAsync(this).execute(triviaURL);
        }
        else {
            trivLoad.setText(getString(R.string.connection_error));
            rButton.setVisibility(View.VISIBLE);
        }
    }

    private boolean isConnectedOnline(){
        ConnectivityManager CManage = ((ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE));
        assert CManage != null;
        NetworkInfo NetworkInfo = CManage.getActiveNetworkInfo();

  return (NetworkInfo != null) && (NetworkInfo.isConnected());
    }
@Override
public void setTriviaReady(boolean begin){
   if (begin) {

       pd.dismiss();
       trivImage.setVisibility(View.VISIBLE);
       trivLoad.setText(getString(R.string.welcome_to_the_triva_app_good_luck));
       trivStart.setEnabled(true);
   }
   else{
       pd = new ProgressDialog(this);
       pd.setCancelable(false);
       pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
       pd.show();
       trivImage.setVisibility(View.INVISIBLE);
       trivLoad.setText(getString(R.string.loading));
       trivStart.setEnabled(false);
   }

}

    @Override
    public void setQuestions(ArrayList<Questions> questions) {
        this.questions = questions;
    }

    private void setupViews() {
        trivImage = (ImageView) findViewById(R.id.TriviaImage);
        trivLoad = (TextView) findViewById(R.id.TriviaLoad);
        trivStart = (Button) findViewById(R.id.StartButton);
        eButton = (Button) findViewById(R.id.ExitButton);
        rButton = (Button) findViewById(R.id.RetryButton);

    }

    @Override
    protected void onDestroy() {
       try {
           if(pd != null && pd.isShowing()) {
               pd.dismiss();
           }
       } catch (Exception e) {
           e.printStackTrace();
       }

    super.onDestroy();
    }

    private void setupListeners() {
        eButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });
        trivStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent triviaIntent = new Intent(MainActivity.this, TriviaActivity.class);
                triviaIntent.putExtra(qKey, questions);
                startActivity(triviaIntent);
            }
        });
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptConnection();
            }
        });


    }
}