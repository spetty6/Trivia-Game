/*
Homework 2
HW02_Group07
Kevin Heu, Samuel Petty
*/

package com.example.hw02_group07;

import android.os.AsyncTask;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;



class QuestionAsync extends AsyncTask<String, Void, ArrayList<Questions>>
{

    private IData activity;

    QuestionAsync(IData activity) {
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        activity.setTriviaReady(false);
    }

    @Override
    protected ArrayList<Questions> doInBackground(String... params) {
        BufferedReader BufReader = null;

        try {
            URL url = new URL(params[0]);
            HttpURLConnection HConnection = (HttpURLConnection) url.openConnection();
            HConnection.setRequestMethod("GET");
            HConnection.connect();

            int statusCode = HConnection.getResponseCode();

            if (statusCode == HttpURLConnection.HTTP_OK) {
                BufReader = new BufferedReader(new InputStreamReader(HConnection.getInputStream()));
                StringBuilder _StringBuilder = new StringBuilder();
                String currLine = BufReader.readLine();

                while (currLine != null) {
                    _StringBuilder.append(currLine);
                    currLine = BufReader.readLine();
                }

                return parseQuestions(_StringBuilder.toString());
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        } finally {
            if (BufReader != null) {
                try {
                    BufReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    private static ArrayList<Questions> parseQuestions(String jsonString) throws JSONException {
        ArrayList<Questions> result = new ArrayList<>();

        JSONObject root = new JSONObject(jsonString);
        JSONArray questionsJson = root.getJSONArray("questions");

        for (int i = 0; i < questionsJson.length(); i++) {
            JSONObject currQuestionJSON = questionsJson.getJSONObject(i);
            Questions currQuestion = new Questions();

            currQuestion.setId(currQuestionJSON.getInt("id"));

            currQuestion.setText(currQuestionJSON.getString("text"));
            currQuestion.setAnswer(currQuestionJSON.getJSONObject("choices").getInt("answer") - 1);

            if (currQuestionJSON.has("image")) {
                currQuestion.setImage(currQuestionJSON.getString("image"));
            }

            JSONArray currQuestionChoicesJSON = currQuestionJSON.getJSONObject("choices").getJSONArray("choice");
            String[] currQuestionChoices = new String[currQuestionChoicesJSON.length()];

            for (int j = 0; j < currQuestionChoices.length; j++) {
                currQuestionChoices[j] = currQuestionChoicesJSON.getString(j);
            }

            currQuestion.setChoices(currQuestionChoices);

            result.add(currQuestion);
        }

        return result;
    }

    @Override
    protected void onPostExecute(ArrayList<Questions> questions) {
        super.onPostExecute(questions);
        activity.setTriviaReady(true);

        activity.setQuestions(questions);
    }

    interface IData {
        void setTriviaReady(boolean ready);

        void setQuestions(ArrayList<Questions> questions);
    }
}

