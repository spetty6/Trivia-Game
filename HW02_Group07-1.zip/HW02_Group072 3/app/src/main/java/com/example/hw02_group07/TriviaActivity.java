/*
Homework 2
HW02_Group07
Kevin Heu, Samuel Petty
*/

package com.example.hw02_group07;

import android.annotation.SuppressLint;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.CountDownTimer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import static java.lang.String.format;


public class TriviaActivity extends AppCompatActivity implements ImageAsync.IData {

    public static final String skey = "Statistics";
    private ArrayList<Questions> questions = new ArrayList<>();
    private Questions currentQ;
    private int aCorrect;
    private int totalAnswers;
    private TextView questionNum;
    private TextView timeLeft;
    private ImageView qImage;
    private CountDownTimer qCount;
    private TextView question;
    private RadioGroup QChoices;
    private Button qButton;
    private Button nButton;
    private ProgressDialog pd;
    private String checkText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia);
        setupViews();
        setupListeners();

        if (getIntent().getExtras() != null){

            this.questions = (ArrayList<Questions>) getIntent().getExtras().getSerializable(MainActivity.qKey);
            this.aCorrect = 0;
            assert questions != null;
            this.totalAnswers = questions.size();
        }
        qCount = new CountDownTimer(120000, 1000) {
            @SuppressLint({"SetTextI18n", "DefaultLocale"})
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeft.setText("Time Remaining: " + format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished),
                        TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
            }

            @Override
            public void onFinish() {
                showStats();
            }
        }.start();
        setQLayout(this.questions.get(0));
    }

    private void setupListeners() {

        qButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qCount.cancel();
                Intent mainIntent = new Intent(TriviaActivity.this, MainActivity.class);
                startActivity(mainIntent);
            }
        });
        nButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkText != null && checkText.equals(currentQ.getChoices()[currentQ.getAnswer()]))
                {
                    aCorrect++;
                }

                if (currentQ.getId() == (questions.size() -1)) {
                    showStats();
                }
                else {
                    setQLayout(questions.get(currentQ.getId() + 1));
                }

            }
        });
        QChoices.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                checkText = ((RadioButton) findViewById(QChoices.getCheckedRadioButtonId())).getText().toString();
            }
        });
    }

    private void showStats(){

        qCount.cancel();

        Intent statIntent = new Intent(this, StatsActivity.class);
        statIntent.putExtra(skey, (((float) aCorrect/totalAnswers) * 100));
        statIntent.putExtra(MainActivity.qKey, questions);
        startActivity(statIntent);
    }

    @SuppressLint("SetTextI18n")
    private void setQLayout(Questions current){
        currentQ = current;
        questionNum.setText("Question" + (current.getId() +1));
        qImage.setVisibility(View.INVISIBLE);

        if (current.getImage() != null){

            pd = new ProgressDialog(this);
            pd.setCancelable(false);
            pd.setMessage("Loading Image...");
            pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pd.show();
            nButton.setEnabled(false);

            if (isConnectedOnline()){
                new ImageAsync(this).execute(current.getImage());
            }
            else {
                Toast.makeText(this, "Not Connected", Toast.LENGTH_LONG).show();
                setTriviaImage(null);
            }

        }

        question.setText(current.getText());

        QChoices.removeAllViews();
        for(int i = 0; i < current.getChoices().length;i++)
        {
            RadioButton radioCurrent = new RadioButton(this);
            radioCurrent.setText(current.getChoices()[i]);
            radioCurrent.setLayoutParams(new RadioGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            QChoices.addView(radioCurrent);
        }

    }

    private boolean isConnectedOnline(){
        ConnectivityManager Connect = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE));
        assert Connect != null;
        NetworkInfo Network = Connect.getActiveNetworkInfo();

        return (Network != null) && (Network.isConnected());
    }

    @Override
    protected void onDestroy() {
        try {
            if (pd != null && pd.isShowing()){
                pd.dismiss();
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
        qCount.cancel();
    }

    @Override
    public void setTriviaImage(Bitmap image){
        pd.dismiss();

        if(image != null) {
            qImage.setImageBitmap(image);
            qImage.setVisibility(View.VISIBLE);
        }
        nButton.setEnabled(true);

    }

    private void setupViews() {
        questionNum = (TextView) findViewById(R.id.QuestionNum);
        timeLeft = (TextView) findViewById(R.id.TimeLeft);
        qImage = (ImageView) findViewById(R.id.QuestionImage);
        question = (TextView) findViewById(R.id.Question);
        QChoices = (RadioGroup) findViewById(R.id.QChoices);
        qButton = (Button) findViewById(R.id.QuitButton);
        nButton = (Button) findViewById(R.id.NextButton);
    }
}




