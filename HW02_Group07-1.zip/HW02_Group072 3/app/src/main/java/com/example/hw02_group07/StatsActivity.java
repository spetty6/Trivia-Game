/*
Homework 2
HW02_Group07
Kevin Heu, Samuel Petty
*/

package com.example.hw02_group07;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;

public class StatsActivity extends AppCompatActivity {
    private ArrayList<Questions> questions = new ArrayList<>();
    float cPercent;
    TextView PercentCorrect;
    ProgressBar PercentProgress;
    TextView StatsMessage;
    Button qButton;
    Button rButton;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        setupViews();
        setupListeners();

        if(getIntent().getExtras() != null) {
            cPercent = getIntent().getExtras().getFloat(TriviaActivity.skey);
       this.questions = (ArrayList<Questions>) getIntent().getExtras().getSerializable(MainActivity.qKey);
        }
        PercentCorrect.setText(cPercent + "%");
        PercentProgress.setProgress((int) cPercent);
        StatsMessage.setText((cPercent == 100.0) ? "Congrats all your answers are correct" : "Missed some try again");
    }

    private void setupListeners() {
        qButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(StatsActivity.this, MainActivity.class);
            startActivity(mainIntent);
            }
        });
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent triviaIntent = new Intent(StatsActivity.this, TriviaActivity.class);
                triviaIntent.putExtra(MainActivity.qKey, questions);
                startActivity(triviaIntent);
            }
        });

    }

    private void setupViews() {
        PercentCorrect = (TextView) findViewById(R.id.PercentCorrect);
        PercentProgress = (ProgressBar) findViewById(R.id.PercentProgress);
        StatsMessage = (TextView) findViewById(R.id.StatsHeading);
        qButton = (Button) findViewById(R.id.QuitButton);
        rButton = (Button) findViewById(R.id.rButton);
    }


}

