/*
Homework 2
HW02_Group07
Kevin Heu, Samuel Petty
*/

package com.example.hw02_group07;

import java.io.Serializable;
import java.util.Arrays;



public class Questions implements Serializable {
    private int id;
    private String text;
    private String image;
    private String[] choices;
    private int answer;

    Questions() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    String getImage() {
        return image;
    }

    void setImage(String image) {
        this.image = image;
    }

   public String[] getChoices() {
        return choices;
    }

    public void setChoices(String[] choices) {
        this.choices = choices;
    }

    int getAnswer() {
        return answer;
    }

    void setAnswer(int answer) {
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "Questions{" +
                "id=" + id +
                ", text='" + text + '\'' +
                ", image='" + image + '\'' +
                ", questions=" + Arrays.toString(choices) +
                ", answer=" + answer +
                '}';
    }


}
