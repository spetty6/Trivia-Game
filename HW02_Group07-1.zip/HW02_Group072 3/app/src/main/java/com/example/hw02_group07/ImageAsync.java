/*
Homework 2
HW02_Group07
Kevin Heu, Samuel Petty
*/

package com.example.hw02_group07;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;



class ImageAsync extends AsyncTask<String, Void, Bitmap> {

    private IData activity;

    ImageAsync (IData activity)
    {
        this.activity = activity;
    }

    @Override
    protected Bitmap doInBackground(String... params)
    {
        try
        {
            URL url = new URL(params[0]);
            HttpURLConnection HConnection = (HttpURLConnection) url.openConnection();
            HConnection.setRequestMethod("GET");
            HConnection.connect();

            int statusCode = HConnection.getResponseCode();

            if(statusCode == HttpURLConnection.HTTP_OK)
            {
                return BitmapFactory.decodeStream(HConnection.getInputStream());
            }
        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return  null;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap)
    {
        super.onPostExecute(bitmap);

        activity.setTriviaImage(bitmap);
    }

    interface IData
    {
        void setTriviaImage(Bitmap image);
    }
}

